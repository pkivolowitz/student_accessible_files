
#	Name:       YOUR NAME GOES HERE
#	Partner:    PARTNER'S NAME IF ANY
#	Class:      example: CSC 1810 - Section 1
#	Project:    NAME OF PROJECT GOES HERE

message = "Hello, world."
print(message)
