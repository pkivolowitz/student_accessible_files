/*  Name:       Prof. Perry Kivolowitz
    Partner:    none
    Class:      CSC 1810 - Section 1
    Project:    ASCII Table

	This program prints an ASCII table showing the decimal, hexadecimal and octal values
	that correspond to each letter printed. The table comes out in two columns and has a
	header that precedes it.

	As this may be your first week of computer programming and you probably don't know the
	C++ programming language, you may have no idea what this is doing... at first!

	Without attempting to look anything up, work with a partner to puzzle through what all
	this does. You can compare the code to what it does. I think you will have enough 
	intuition and insight to figure out your first program.

	Try tinkering with the "first_letter", for example, to see what changes. Alter other
	values. Experiement. Hack!
*/

#include <iostream>
#include <iomanip>

using namespace std;

/*	PrintData()

	This function is passed a single letter (and a column width). It returns nothing.
	The letter is printed along with its decimal, hexadecimal and octal values.
*/
void PrintData(char letter, int column_width) {
	cout << setw(3) << left << letter << right << setw(column_width);
	cout << int(letter) << right << setw(column_width) << hex << int(letter);
	cout << right << setw(column_width) << oct << int(letter) << dec;
}

/*	PrintHeader()

	This function prints two copies of the heading for the ASCII table. Both
	copies are the same, so they are printed in a loop to avoid duplicated code.
*/
void PrintHeader(int column_width) {
	for (int i = 0; i < 2; i++ ) {
		cout << left << setw(3) << "CHR" << right << setw(column_width) << "DEC" << right;
		cout << setw(column_width) << hex << "HEX" << right << setw(column_width) << oct << "OCT" << dec;
		if (i == 0)
			cout << setw(column_width) << " ";
	}
	cout << endl;
}

int main(int argc, char * argv[]) {
	int width = 6;
	char first_letter = 'a';

	PrintHeader(width);
	for (int i = 0; i < 13; i++) {
		PrintData(char(i + first_letter), width);
		cout << setw(width) << " ";
		PrintData(char(i + 13 + first_letter), width);
		cout << endl;
	}
	cout << endl;

    // This causes the program to pause at its completion.
    {
        char c;
        cout << "Hit enter to exit:";
        cin.get(c); 
    }
    return 0;
}