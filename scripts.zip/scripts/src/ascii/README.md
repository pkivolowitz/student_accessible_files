# ASCII Table

During the spring term of 2018, my kid made the observation that we teach people
to write code but we don't teach people to read code. I couldn't get that comment
out of my head. I thought deeply about how I learned to code and... it was *more* by
reading code than by writing it.

For interest's sake, I learned C from these two sources:

- [Peter S. Langston's](http://www.langston.com/index.html) pioneering Unix games.
- The source code of Unix Version 6 (a 1970's vintage operating system).

With my kid's words still in my head, let us take a decidedly non-traditional 
approach to your first C / C++ program. Instead of writing Hello World, let's 
read and decode a tiny but not totally trivial program.

# The traditional first program

[Hello World](https://en.wikipedia.org/wiki/%22Hello,_World!%22_program)
is the traditional first program any person learning a new programming
language writes. This tradition goes way back to Brian Kernighan's book "The C Programming Language." That's the book I had in the late 1970's, BTW. 

Here is Brian Kernighan's version in C:

```c
#include <stsdio.h>

main() {
	printf("hello, world\n");
}
```

Here is a C++ version:

```c++
#include <iostream>

int main() {
	std::cout << "hello, world" << std::endl;
	return 0;
}
```

The strange punctuation in the printed string is historically accurate and has been a subject of discussion ever since.

Here is a [link](http://helloworldcollection.de/) to more than one hundred variations of this program.

# What is this file?

This file is written in "markdown". Markdown is a simple formatting language
that is in common use for online documentation. A cool thing about markdown is
that Visual Studio Code knows how to render it built-in!

While this file is open in Code, press control-k then v. On the Mac, press
command-k then v. 
