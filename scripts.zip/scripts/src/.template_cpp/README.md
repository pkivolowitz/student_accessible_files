# Markdown

This is a markdown document. markdown is an easy way to make nice looking
documentation of your work. Here is a [link](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) to markdown syntax.

Visual Studio Code knows how to render / preview markdown. Hit cntl-k then v on Windows or cmd-k then v on the Mac while editing a markdown document.

