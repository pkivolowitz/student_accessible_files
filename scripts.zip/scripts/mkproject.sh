#!/bin/bash

if [ ! -d "src" ]
then
	echo "Your src directory is missing or corrupted. Please contact your instructor."
	read -r -p "Hit enter to exit:" -n 1
	exit 1
fi

read -p "Enter P for Python or C for C++: " project_type

case $project_type in
	P)
		template_project=".template_python"
		;;
	C)
		template_project=".template_cpp"
		;;
	*)
		echo "Invalid input."
		read -r -p "Hit enter to exit:" -n 1
		;;
esac

cd src

read -p "Enter the name of the new project followed by [ENTER]: " project_name

if [ -e $project_name ]
then
	echo "A file or directory with that name exists. Choose a name that is not a file or directory"
	read -r -p "Hit enter to exit:" -n 1
	exit 1
fi

if [[ ! -d $template_project ]]
then
	echo "The template in ~/src is missing. See instructor."
	read -r -p "Hit enter to exit:" -n 1
	exit 1
fi

mkdir -p $project_name
if [ $? -ne 0 ]
then
	echo "Failed to create project directory named " $project_name " in ~/src"
	read -r -p "Hit enter to exit:" -n 1
	exit 1
fi

cp $template_project/* $project_name
mkdir $project_name/.vscode
cp $template_project/.vscode/* $project_name/.vscode
mv $project_name/template.code-workspace $project_name/$project_name.code-workspace
chmod 775 $project_name
chmod 664 $project_name/*
echo "Project:" $project_name "has been created."
exit 0


