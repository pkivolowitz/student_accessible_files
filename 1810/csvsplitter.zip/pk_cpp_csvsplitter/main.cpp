#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

#include "simple_csv.hpp"

using namespace std;

int main(const int argc, const char * argv[]) {
	int retval = 0;
	if (argc < 2) {
		cerr << "Usage: [prog] [csvfile]\n";
		retval = 1;
	} else {
		ifstream infile(argv[1]);
		if (infile.is_open()) {
			string line;
			int counter = 0;
			while (getline(infile, line)) {
				counter++;
				vector<string> tokens = SimpleSplit(line, ',', SS_NOQUOTES | SS_TRIM);
				cout << "Line: " << setw(5) << counter << " Length:" <<setw(4) << tokens.size() << " ";
				for (auto s : tokens) {
					cout << "[" << s << "] ";
				}
				cout << endl;
			}
			infile.close();
		} else {
			cerr << "Could not open: " << argv[1] << endl;
			retval = 1; 
		}
	}
	return retval;
}