/*	Not replacing this with your name is worth -5 points!
*/

#include <iostream>
#include <iomanip>
#include <vector>
#include <ctime>

using namespace std;

/*	Print() - this function... write big picture comment here.

	Parameters:
	string			printed before the data
	vector<int> &	A reference to a vector of int

	Returns:
	void				No return value
*/

void Print(string title, vector<int> & values) {
	// You write this

}

/*	Write function comment in style of above.
*/

void Insert(vector<int> & values, int value) {
	// You write this
}

/*	Write function comment in style of above.
*/

void InsertionSort(vector<int> & values, const size_t size, const int max_value) {
	// You write this
}

int main() {
	const size_t vector_size = 64;
	const int max_value = 65536;
	vector<int> values;

	srand((unsigned int) time(nullptr));
	InsertionSort(values, vector_size, max_value);
	Print("After", values);

	return 0;
}
